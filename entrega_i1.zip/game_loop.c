/**
 * @brief It defines the game loop
 *
 * @file game_loop.c
 * @author Profesores PPROG
 * @version 0
 * @date 24-01-2026
 * @copyright GNU Public License
 */

#include <stdio.h>
#include <stdlib.h>

#include "command.h"
#include "game.h"
#include "game_reader.h"
#include "game_actions.h"
#include "graphic_engine.h"

/**
 * @brief It initializes the game and graphic engine
 * @author Iker Díaz
 *
 * @param game a pointer to the game
 * @param gengine a pointer to the graphic engine pointer
 * @param file_name path to the game data file
 * @return 0 if OK, 1 if game initialization fails, 2 if graphic engine initialization fails
 */
int game_loop_init(Game *game, Graphic_engine **gengine, char *file_name);

/**
 * @brief It frees all allocated resources
 * @author Profesores PPROG
 *
 * @param game the game instance
 * @param gengine a pointer to the graphic engine
 */
void game_loop_cleanup(Game game, Graphic_engine *gengine);

/**
 * @brief Main entry point of the game
 * @author Profesores PPROG
 *
 * @param argc number of command line arguments
 * @param argv array with command line arguments
 * @return 0 if the execution finishes correctly, 1 otherwise
 */

int main(int argc, char *argv[]) {
  Game game;
  Graphic_engine *gengine;
  int result;
  Command *last_cmd;

  if (argc < 2) {
    fprintf(stderr, "Use: %s <game_data_file>\n", argv[0]);
    return 1;
  }

  result = game_loop_init(&game, &gengine, argv[1]);

  if (result == 1) {
    fprintf(stderr, "Error while initializing game.\n");
    return 1;
  } else if (result == 2) {
    fprintf(stderr, "Error while initializing graphic engine.\n");
    return 1;
  }

  last_cmd = game_get_last_command(&game);

  while ((command_get_code(last_cmd) != EXIT) && (game_get_finished(&game) == FALSE)) {
    graphic_engine_paint_game(gengine, &game);
    command_get_user_input(last_cmd);
    game_actions_update(&game, last_cmd);
  }

  game_loop_cleanup(game, gengine);

  return 0;
}

int game_loop_init(Game *game, Graphic_engine **gengine, char *file_name) {
  if (game_reader_create_from_file(game, file_name) == ERROR) {
    return 1;
  }

  if ((*gengine = graphic_engine_create()) == NULL) {
    game_destroy(game);
    return 2;
  }

  return 0;
}

void game_loop_cleanup(Game game, Graphic_engine *gengine) {
  game_destroy(&game);
  graphic_engine_destroy(gengine);
}
